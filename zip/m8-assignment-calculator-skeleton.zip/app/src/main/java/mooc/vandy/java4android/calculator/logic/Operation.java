package mooc.vandy.java4android.calculator.logic;

public interface Operation {
    String operation(int num1, int num2);  // Interface Operation for abstract method
}
